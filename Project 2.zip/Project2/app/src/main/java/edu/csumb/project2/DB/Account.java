package edu.csumb.project2.DB;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity (tableName = "account")
public class Account {

    String password;
    //String reservations;
    @PrimaryKey
    @NonNull
    String username;

    public Account(String username, String password){
        this.username = username;
        this.password = password;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @NonNull
    public String getUsername() {
        return username;
    }

    public void setUsername(@NonNull String username) {
        this.username = username;
    }

    public static Account[] populate() {
        Account[] ac = new Account[4];
        ac[0] = new Account("admin2","admin2");
        ac[1] = new Account("alice5","csumb100");
        ac[2] = new Account("brian77","123ABC");
        ac[3] = new Account("chris21","CHRIS21");
        return ac;
    }

    @NonNull
    @Override
    public String toString() {
        return "UN: "+this.username;
    }
}
