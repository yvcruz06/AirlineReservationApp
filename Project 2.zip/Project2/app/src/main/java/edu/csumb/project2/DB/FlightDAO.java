package edu.csumb.project2.DB;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface FlightDAO {
    @Insert
    public void insert(Flight... flights);

    @Update
    public void update(Flight... flights);

    @Delete
    public void delete(Flight... flights);

    @Query("SELECT * FROM flight")
    public List<Flight> getAllFlights();

    @Query("SELECT * FROM flight WHERE departure = :dep AND arrival = :arr AND flight_cap >= :tickets")
    public List<Flight> getFlights(String dep, String arr, int tickets);

}
