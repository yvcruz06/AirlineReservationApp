package edu.csumb.project2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.ButtonBarLayout;
import androidx.room.Room;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import edu.csumb.project2.DB.Account;
import edu.csumb.project2.DB.AccountDAO;
import edu.csumb.project2.DB.AppDatabase;

public class MainActivity extends AppCompatActivity {

    TextView mtextView;
    Button mButton1;
    Button mButton2;
    Button mButton3;
    Button mButton4;

    AccountDAO accountDAO;

    boolean m1 =  true;
    private static final String M1ISTRUE = "edu.csumb.project2";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mtextView = (TextView) findViewById(R.id.textView);
        mButton1 = (Button) findViewById(R.id.button);
        mButton2 = (Button) findViewById(R.id.button2);
        mButton3 = (Button) findViewById(R.id.button3);
        mButton4 = (Button) findViewById(R.id.button4);


        mButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = CreateAccount.newIntent(MainActivity.this, m1);
                startActivity(intent);
            }
        });

        mButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = ReserveSeat.newIntent(MainActivity.this, m1);
                startActivity(intent);
            }
        });


        mButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = CR_Login.newIntent(MainActivity.this, m1);
                startActivity(intent);
            }
        });

        mButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = CR_Login.newIntent(MainActivity.this, m1);
                startActivity(intent);
            }
        });

        accountDAO = Room.databaseBuilder( this, AppDatabase.class, "db-accounts")
                .allowMainThreadQueries()
                .build()
                .getAccountDAO();
        //accountDAO.insertAccounts(Account.populate());


    }

    public static Intent newIntent(Context context, boolean m1) {
        Intent intent = new Intent(context, MainActivity.class);
        intent.putExtra(M1ISTRUE,m1);
        return intent;
    }
}
