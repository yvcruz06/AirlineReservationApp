package edu.csumb.project2.DB;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface AccountDAO {
    @Insert
    public void insert(Account... accounts);

    @Insert(onConflict = OnConflictStrategy.FAIL)
    public void insertAccounts(Account... accounts);

    @Update
    public void update(Account... accounts);

    @Delete
    public void delete(Account... accounts);

    @Query("SELECT * FROM account")
    public List<Account> getAccounts();

    @Query("SELECT username FROM account WHERE username = :un")
    public String getAccountWithUN(String un);
}
