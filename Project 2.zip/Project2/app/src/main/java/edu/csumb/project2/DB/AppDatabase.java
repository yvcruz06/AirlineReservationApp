package edu.csumb.project2.DB;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database( entities = {Account.class, Flight.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {

    public abstract AccountDAO getAccountDAO();

    public abstract FlightDAO getFlightDAO();
}
