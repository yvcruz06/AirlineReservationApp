package edu.csumb.project2.DB;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity (tableName = "flight")
public class Flight {

    String departure;
    String arrival;
    int dep_time;
    int flight_cap;
    int price;

    @PrimaryKey
    @NonNull
    String flight_no;

    public Flight(String flight_no, String departure, String arrival,
                   int dep_time, int flight_cap, int price) {
        this.flight_no = flight_no;
        this.departure = departure;
        this.arrival = arrival;
        this.dep_time = dep_time;
        this.flight_cap = flight_cap;
        this.price = price;
    }

    public String getDeparture() {
        return departure;
    }

    public void setDeparture(String departure) {
        this.departure = departure;
    }

    public String getArrival() {
        return arrival;
    }

    public void setArrival(String arrival) {
        this.arrival = arrival;
    }

    public int getDep_time() {
        return dep_time;
    }

    public void setDep_time(int dep_time) {
        this.dep_time = dep_time;
    }

    public int getFlight_cap() {
        return flight_cap;
    }

    public void setFlight_cap(int flight_cap) {
        this.flight_cap = flight_cap;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    @NonNull
    public String getFlight_no() {
        return flight_no;
    }

    public void setFlight_no(@NonNull String flight_no) {
        this.flight_no = flight_no;
    }

    @Override
    public String toString() {
        return "Flight{" +
                " flight_no='" + flight_no + '\'' +
                ", departure='" + departure + '\'' +
                ", arrival='" + arrival + '\'' +
                ", dep_time=" + dep_time +
                ", flight_cap=" + flight_cap +
                ", price=" + price +
                '}';
    }
}
