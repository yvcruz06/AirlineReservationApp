package edu.csumb.project2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class ReserveSeat extends AppCompatActivity {

    EditText mEditText1;
    EditText mEditText2;
    EditText mEditText3;
    Button mButton1;


    boolean m1 =  true;
    private static final String M1ISTRUE = "edu.csumb.project2";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reserve_seat);

        mEditText1 = (EditText) findViewById(R.id.editText3);
        mEditText2 = (EditText) findViewById(R.id.editText4);
        mEditText3 = (EditText) findViewById(R.id.editText5);
        mButton1 = (Button) findViewById(R.id.button6);
    }


    public static Intent newIntent(Context context, boolean m1) {
        Intent intent = new Intent(context, ReserveSeat.class);
        intent.putExtra(M1ISTRUE,m1);
        return intent;
    }
}
