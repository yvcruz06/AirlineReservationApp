package edu.csumb.project2.DB;

public interface ResLogDAO {
}
