package edu.csumb.project2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.regex.Pattern;

import edu.csumb.project2.DB.Account;
import edu.csumb.project2.DB.AccountDAO;
import edu.csumb.project2.DB.AppDatabase;

public class CreateAccount extends AppCompatActivity {

    EditText mEditText1;
    EditText mEditText2;
    Button mButton1;

    AccountDAO accountDAO;

    boolean m1 =  true;
    private static final String M1ISTRUE = "edu.csumb.project2";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        mEditText1 = (EditText) findViewById(R.id.editText);
        mEditText2 = (EditText) findViewById(R.id.editText2);
        mButton1 = (Button) findViewById(R.id.button5);

        accountDAO = Room.databaseBuilder( this, AppDatabase.class, "db-accounts")
                .allowMainThreadQueries()
                .build()
                .getAccountDAO();

        mButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                makeAccount();
            }
        });

    }

    public void makeAccount(){
        String un = mEditText1.getText().toString();
        String pw = mEditText2.getText().toString();

        if (accountDAO.getAccountWithUN(un) == null) {
            if (stringContainsNumber(un) && stringContainsNumber(pw) && letterCount(un) >= 3 && letterCount(pw) >= 3) {

                accountDAO.insert(new Account(un, pw));
                Toast.makeText(this, "Account made successful", Toast.LENGTH_LONG).show();

                //log info

                Intent intent = MainActivity.newIntent(CreateAccount.this, m1);
                startActivity(intent);
            }
            else {
                Toast.makeText(this, "Account not valid", Toast.LENGTH_LONG).show();
            }
        }
        else {
            Toast.makeText(this, "Account exists", Toast.LENGTH_LONG).show();
        }
    }


    public static Intent newIntent(Context context, boolean m1) {
        Intent intent = new Intent(context, CreateAccount.class);
        intent.putExtra(M1ISTRUE,m1);
        return intent;
    }

    public boolean stringContainsNumber(String s) {
        return Pattern.compile( "[0-9]" ).matcher( s ).find();
    }

    public int letterCount(String s) {
        int count = 0;
        for (int i = 0; i < s.length(); i++) {
            if (Character.isLetter(s.charAt(i)))
                count++;
        }
        return count;
    }
}
